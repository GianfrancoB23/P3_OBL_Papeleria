﻿using Empresa.LogicaDeNegocio.Entidades;
using Papeleria.LogicaNegocio.InterfacesRepositorio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Papeleria.AccesoDatos.Memoria
{
    public class RepositorioComunesMemoria : IRepositorioComun
    {
        public void Add(Comunes obj)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Comunes> GetAll()
        {
            throw new NotImplementedException();
        }

        public Comunes GetById(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Comunes> GetObjectsByID(List<int> ids)
        {
            throw new NotImplementedException();
        }

        public void Remove(int id)
        {
            throw new NotImplementedException();
        }

        public void Remove(Comunes obj)
        {
            throw new NotImplementedException();
        }

        public void Update(int id, Comunes obj)
        {
            throw new NotImplementedException();
        }
    }
}

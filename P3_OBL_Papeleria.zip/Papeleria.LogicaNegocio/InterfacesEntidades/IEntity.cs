using Empresa.LogicaDeNegocio.Sistema;
using Papeleria.LogicaNegocio.Entidades.ValueObjects;

namespace Empresa.LogicaDeNegocio.Entidades
{
	public interface IEntity
	{
		public int Id { get; set; }
    }

}

